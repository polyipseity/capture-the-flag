<?php
//PUCTF24{this_is_fake_flag}
?>